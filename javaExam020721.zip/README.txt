------------------------------------------------------------------------------------------------
                        J A V A     E X A M     J U L Y     0 2 ,    2 0 2 1
------------------------------------------------------------------------------------------------

Author: Christian Dal Pez 

All these files are part of the "JavaExam" test, scheduled for July 02, 2021. 
Note: each assignment is contained in a different file.java, except for "Stores" exercise which is contained in a folder
containing a file.java for every class (main, mainStore and trentoStore). 
