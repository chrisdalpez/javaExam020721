import java.util.ArrayList;

public class contest {
    
    public static void main (String args[]) {

        ArrayList<String> participants = new ArrayList();
        
        participants.add("Marta");
        participants.add("Peppo");
        participants.add("Elisa");
        participants.add("Gioele");
        participants.add("Rosa");
        
        contest(participants);
        
        System.out.println(participants);
    }

    static void contest(ArrayList<String> participants){    

            for (int k = 0; k < participants.size(); k++){ 
                participants.set(k,participants.get(k) + " - " + (k + 1)); 
            }
    }

}
