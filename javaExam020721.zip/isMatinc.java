public class isMatinc {

    public static void main(String args[]) {
        
        int[][] mat1 = {{1,4,6,7,9},
                {0,1,2,4,8},
                {2,6,8,9,10},
                {0,1,2,4,8},
                {0,1,5,7,9},
                {1,2,3,8,9}};

        System.out.println(isMatinc(mat1));  // true

        int[][] mat2 = {{0,1,3,4},                
                        {0,1,3,4},
                        {0,1,2,4},
                        {1,4,6,7},
                        {1,4,6,7},
                        {2,6,8,9},
                        {0,1,5,7},
                        {1,2,3,8}};

        System.out.println(isMatinc(mat2));  // true

        int[][] mat3 = {{1,4,5,7,9},
                        {0,1,2,4,8},
                        {2,6,3,9,10},
                        {1,5,3,8,7}};

        System.out.println(isMatinc(mat3));  // false

        int[][] mat4 = {{1,4,7,7,9},
                        {0,1,2,4,8},
                        {3,2,6,8,9}};

        System.out.println(isMatinc(mat4));  // false
    }


    public static boolean isMatinc(int[][] matrice){ 

        int checker = 0;
 
        for(int i = 0; i < matrice.length; i++){ 
            for(int j = 1; j < matrice[i].length; j++){ 

                if( matrice[i][j-1] < matrice[i][j] ){ 
                    checker = matrice[i][j]; 

                } else { 

                    return false; 

                } 
            } 
        } 

        return true; 
    }
}
