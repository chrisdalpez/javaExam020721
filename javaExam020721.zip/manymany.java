public class manymany {
    
    public static void main(String args []) {

        System.out.println(manymany("rospo", "14323"));          // "roooosssppooo"
    
        System.out.println(manymany("artificio", "144232312"));  // "arrrrttttiifffiicccioo")
    }

    static String manymany(String word, String repetitions){   

        StringBuilder manyWords = new StringBuilder(); 

        for (int i = 0; i < word.length(); i++) {
            int repeated = Integer.parseInt(repetitions.substring(i, i + 1)); 

            for (int k = 0; k < repeated; k++) {
                manyWords.append(word.charAt(i));
            }
                
        }
        return manyWords.toString();   
    }
    
}
