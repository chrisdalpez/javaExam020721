package Store;

public class trentoStore extends mainStore {

    private int discount = 20; 
   // super(qty); 

    public trentoStore(int qty) {
        super(qty); 
    }

    @Override 
    public double price(int qty) {
        double lampsCost = super.price(qty); 

        if (qty >= 500 && lampsCost > 0) {
            return lampsCost - ((lampsCost*20)/100); 
        } else {
            return lampsCost; 
        }
    }
}
