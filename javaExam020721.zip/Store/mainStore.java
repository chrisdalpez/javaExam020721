package Store;

public class mainStore {

    private int lamps; 
    private int price = 10; 

    public mainStore(int lamps) {
        this.lamps = lamps; 
    }



    public double price(int qty) {

        if (lamps < qty) {
            return -1; 
        } else {
            return price * qty; 
        }    
    }

    public void sell(int qty) {
        System.out.println("DEBUG: Stock is " + lamps);

        if (lamps > qty) {
            System.out.println("DEBUG: sold " + qty + " items");
            lamps = lamps - qty; //lamps left after purchasing a stock. 

        } else {
            System.out.println("DEBUG: WARNING: THERE ARE ONLY " + lamps + " ITEMS AVAILABLE.");
            lamps = 0; 
        }

        System.out.println("DEBUG: stock is now " + lamps);
    }



         

}
