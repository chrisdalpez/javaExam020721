package Store;

public class main {
    
    public static void main(String args[]) {

        System.out.println("*** mainStore:");
        mainStore mainStore = new mainStore(5000);
        System.out.println("  price(400): " + mainStore.price(400) + " €");
        System.out.println("  price(1000): " + mainStore.price(1000) + " €");
        System.out.println();
        System.out.println("  sell(400)");
        mainStore.sell(400);
        System.out.println("  sell(1000)");
        mainStore.sell(1000);
        System.out.println("  sell(8000)");
        mainStore.sell(8000);


        System.out.println();

        System.out.println("*** trentoStore:");
        trentoStore trentoStore = new trentoStore(1000);
        System.out.println("  price(400): " + trentoStore.price(400) + " €");
        System.out.println("  price(1000): " + trentoStore.price(1000) + " €");  // discounted
        System.out.println();
        System.out.println("  sell(400)");
        trentoStore.sell(400);
        System.out.println("  sell(1000)");
        trentoStore.sell(1000);
    }
}
